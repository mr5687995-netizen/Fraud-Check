# FraudGuard Android — User ও Admin

এটি একটি অফলাইন Android Studio সোর্স প্রজেক্ট; এখানে দুটি আলাদা অ্যাপ মডিউল আছে:
- `userapp`: মেসেজ/লিংক/অ্যাকাউন্ট/অনলাইন শপের ঝুঁকি যাচাই, লোকাল নোট, রিপোর্ট সংরক্ষণ ও JSON এক্সপোর্ট।
- `adminapp`: JSON রিপোর্ট ইমপোর্ট, রিপোর্ট পর্যালোচনা এবং স্ট্যাটাস পরিবর্তন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি APK ফাইল নয়; Android Studio দিয়ে build করে APK তৈরি করতে হবে।
- অফলাইন অ্যাপের রিপোর্ট স্বয়ংক্রিয়ভাবে অন্য ফোনে যায় না। User App থেকে JSON export করে Admin App-এ import করতে হবে।
- "স্থানীয় চ্যাট" অন্য কাউকে মেসেজ পাঠায় না; এটি একই ফোনে নোট/মেসেজ সংরক্ষণের সুবিধা।
- স্ক্যানারটি rule-based heuristic, AI বা সরকারি/ব্যাংক ডেটাবেস যাচাই নয়। "উচ্চ ঝুঁকি" মানেই নিশ্চিত প্রতারণা নয়, এবং "কম সংকেত" মানেই নিরাপদ নয়।
- কোনো অ্যাপের ব্যক্তিগত SMS/মেসেজ স্বয়ংক্রিয়ভাবে পড়ে না। ব্যবহারকারী নিজে টেক্সট পেস্ট করে পরীক্ষা করবেন।

## Build করার ধাপ
1. ZIP extract করুন।
2. Android Studio-তে `FraudGuardAndroid` ফোল্ডার Open করুন।
3. Gradle sync সম্পন্ন হতে দিন (প্রথম build-এ ইন্টারনেট লাগতে পারে, কারণ Gradle dependencies ডাউনলোড হয়)।
4. `userapp` বা `adminapp` মডিউল নির্বাচন করে Build > Build APK(s) ব্যবহার করুন।
5. APK সাধারণত `userapp/build/outputs/apk/debug/` এবং `adminapp/build/outputs/apk/debug/`-এ তৈরি হবে।

## Offline storage
ডেটা Android SharedPreferences-এ থাকে; অ্যাপ আনইনস্টল করলে ডেটা মুছে যেতে পারে। গুরুত্বপূর্ণ রিপোর্ট JSON হিসেবে export করে রাখুন।

## APK তৈরি করার বিকল্প (কম্পিউটার ছাড়া GitHub Actions)
এই প্রজেক্টে `.github/workflows/build-apk.yml` যুক্ত আছে।
1. ZIP Extract করে ফাইলগুলো একটি GitHub repository-তে upload করুন।
2. GitHub repository-তে Actions ট্যাব খুলুন।
3. `Build FraudGuard APKs` workflow নির্বাচন করে `Run workflow` চাপুন।
4. Build সফল হলে workflow run-এর Artifacts অংশ থেকে `FraudGuard-Android-APKs` ZIP ডাউনলোড করুন। এর মধ্যে User ও Admin APK থাকবে।
প্রথমবার build করার সময় GitHub Actions-এ নেটওয়ার্ক সংযোগ লাগে। Build সফল হবে—এমন নিশ্চয়তা নয়; কোনো compilation error হলে তা ঠিক করতে হবে।
