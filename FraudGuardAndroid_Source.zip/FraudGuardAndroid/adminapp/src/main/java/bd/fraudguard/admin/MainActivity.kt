package bd.fraudguard.admin

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF087F5B)
private const val STORE = "fraudguard_admin"
private const val REPORTS = "reports"
data class Report(val id: String, val type: String, val content: String, val risk: String, val reasons: List<String>, val time: String, val status: String = "নতুন")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Color(0xFFF5F8F6))) { AdminApp(this) } }
    }
}
private fun load(ctx: Context): List<Report> {
    val arr = JSONArray(ctx.getSharedPreferences(STORE, 0).getString(REPORTS, "[]"))
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i); val rs = o.optJSONArray("reasons") ?: JSONArray()
        Report(o.optString("id"),o.optString("type"),o.optString("content"),o.optString("risk"),
            (0 until rs.length()).map { rs.optString(it) },o.optString("time"),o.optString("status","নতুন"))
    }.reversed()
}
private fun persist(ctx: Context, list: List<Report>) {
    val a = JSONArray()
    list.reversed().forEach { r -> a.put(JSONObject().put("id",r.id).put("type",r.type).put("content",r.content).put("risk",r.risk).put("reasons",JSONArray(r.reasons)).put("time",r.time).put("status",r.status)) }
    ctx.getSharedPreferences(STORE,0).edit().putString(REPORTS,a.toString()).apply()
}
@Composable
private fun AdminApp(ctx: Context) {
    var reports by remember { mutableStateOf(load(ctx)) }
    var message by remember { mutableStateOf("রিপোর্ট ইমপোর্ট করলে তালিকা এখানে দেখা যাবে।") }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val outcome = runCatching {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("ফাইল পড়া যায়নি")
                val root = JSONObject(text)
                val arr = root.optJSONArray("reports") ?: error("সঠিক FraudGuard JSON ফাইল নয়")
                val existing = load(ctx).associateBy { it.id }.toMutableMap()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i); val reasons = o.optJSONArray("reasons") ?: JSONArray()
                    val id = o.optString("id", System.currentTimeMillis().toString() + i)
                    existing[id] = Report(id,o.optString("type"),o.optString("content"),o.optString("risk"),
                        (0 until reasons.length()).map { reasons.optString(it) },o.optString("time"),"নতুন")
                }
                persist(ctx, existing.values.toList())
                reports = load(ctx)
                "ইমপোর্ট সম্পন্ন: ${reports.size}টি রিপোর্ট"
            }
            message = outcome.getOrElse { "ইমপোর্ট ব্যর্থ: ${it.message ?: "ফাইলটি যাচাই করুন"}" }
        }
    }
    Scaffold { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(16.dp), color = Green, modifier = Modifier.size(48.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.AdminPanelSettings, null, tint = Color.White) } }
                Spacer(Modifier.width(12.dp))
                Column { Text("FraudGuard Admin", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("অফলাইন রিপোর্ট যাচাই") }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("User App থেকে রিপোর্ট আনুন", fontWeight = FontWeight.Bold)
                    Text("User App → রিপোর্ট → রিপোর্ট এক্সপোর্ট। এরপর এই অ্যাপে JSON ফাইল ইমপোর্ট করুন।")
                    Button(onClick = { importLauncher.launch(arrayOf("application/json", "text/*", "*/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("JSON রিপোর্ট ইমপোর্ট")
                    }
                    OutlinedButton(onClick = { reports = load(ctx); message = "তালিকা আপডেট হয়েছে।" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("রিফ্রেশ") }
                    Text(message, color = Green)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("মোট রিপোর্ট", reports.size.toString(), Modifier.weight(1f))
                StatCard("উচ্চ ঝুঁকি", reports.count { it.risk == "উচ্চ ঝুঁকি" }.toString(), Modifier.weight(1f))
                StatCard("নতুন", reports.count { it.status == "নতুন" }.toString(), Modifier.weight(1f))
            }
            Text("রিপোর্ট তালিকা", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (reports.isEmpty()) Text("রিপোর্ট নেই। প্রথমে User App থেকে JSON ফাইল ইমপোর্ট করুন।")
            reports.forEachIndexed { index, r ->
                var status by remember(r.id, r.status) { mutableStateOf(r.status) }
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("${r.type} • ${r.risk}", fontWeight = FontWeight.Bold, color = if (r.risk == "উচ্চ ঝুঁকি") Color(0xFFB42318) else Green)
                        Text(r.content)
                        Text("সময়: ${r.time}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text(r.reasons.joinToString(" • "), style = MaterialTheme.typography.bodySmall)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("অবস্থা", fontWeight = FontWeight.Medium)
                            Spacer(Modifier.width(8.dp))
                            var expanded by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(onClick = { expanded = true }) { Text(status); Icon(Icons.Default.ArrowDropDown, null) }
                                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    listOf("নতুন","যাচাই চলছে","যাচাইকৃত","ভুল রিপোর্ট").forEach { s ->
                                        DropdownMenuItem(text = { Text(s) }, onClick = {
                                            status = s; expanded = false
                                            val updated = reports.toMutableList()
                                            updated[index] = r.copy(status = s)
                                            reports = updated
                                            persist(ctx, reports)
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text("নোট: Admin ডেটা এই ডিভাইসে আলাদাভাবে থাকে; User App-এর সঙ্গে সরাসরি সিঙ্ক হয় না।", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}
@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Green)
            Text(title, style = MaterialTheme.typography.labelSmall)
        }
    }
}
