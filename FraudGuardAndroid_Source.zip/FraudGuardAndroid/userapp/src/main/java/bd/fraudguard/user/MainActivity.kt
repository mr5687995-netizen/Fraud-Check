package bd.fraudguard.user

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF087F5B)
private val Ink = Color(0xFF172B25)
private const val STORE = "fraudguard_user"
private const val REPORTS = "reports"
private const val NOTES = "local_messages"

data class Report(val id: String, val type: String, val content: String, val risk: String, val reasons: List<String>, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Green, onPrimary = Color.White, background = Color(0xFFF5F8F6))) { UserApp(this) } }
    }
}

private fun prefs(ctx: Context) = ctx.getSharedPreferences(STORE, Context.MODE_PRIVATE)
private fun loadReports(ctx: Context): List<Report> {
    val arr = JSONArray(prefs(ctx).getString(REPORTS, "[]"))
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val rs = o.optJSONArray("reasons") ?: JSONArray()
        Report(o.optString("id"), o.optString("type"), o.optString("content"), o.optString("risk"),
            (0 until rs.length()).map { rs.optString(it) }, o.optString("time"))
    }.reversed()
}
private fun saveReport(ctx: Context, r: Report) {
    val old = JSONArray(prefs(ctx).getString(REPORTS, "[]"))
    val out = JSONArray()
    for (i in 0 until old.length()) out.put(old.getJSONObject(i))
    out.put(JSONObject().put("id", r.id).put("type", r.type).put("content", r.content).put("risk", r.risk)
        .put("reasons", JSONArray(r.reasons)).put("time", r.time))
    prefs(ctx).edit().putString(REPORTS, out.toString()).apply()
}
private fun analyze(text: String, type: String): Pair<String, List<String>> {
    val s = text.lowercase(Locale.ROOT)
    val reasons = mutableListOf<String>()
    val urlPattern = Regex("""(https?://|www\.)[^\s]+""", RegexOption.IGNORE_CASE)
    val urls = urlPattern.findAll(text).map { it.value }.toList()
    if (urls.isNotEmpty()) {
        reasons.add("মেসেজে লিংক আছে—ডোমেইন নিজে যাচাই করুন")
        if (urls.any { u -> listOf("bit.ly", "tinyurl", "t.co", "rb.gy", "is.gd").any { u.contains(it, true) } })
            reasons.add("শর্ট করা URL পাওয়া গেছে")
        if (urls.any { it.contains("@") || it.contains("xn--", true) }) reasons.add("URL-এ বিভ্রান্তিকর/অস্বাভাবিক অংশ থাকতে পারে")
    }
    val urgent = listOf("এখনই", "জরুরি", "urgent", "immediately", "account blocked", "অ্যাকাউন্ট বন্ধ", "শেষ সুযোগ", "verify now")
    if (urgent.any { s.contains(it) }) reasons.add("জরুরি সিদ্ধান্ত নিতে চাপ দেওয়ার ভাষা আছে")
    val money = listOf("বিকাশ", "নগদ", "রকেট", "টাকা পাঠান", "send money", "payment", "টাকা দিন", "অগ্রিম")
    if (money.any { s.contains(it) }) reasons.add("টাকা/পেমেন্ট সংক্রান্ত অনুরোধ আছে")
    val secret = listOf("otp", "পিন", "pin", "password", "পাসওয়ার্ড", "পাসওয়ার্ড", "verification code", "কোড দিন")
    if (secret.any { s.contains(it) }) reasons.add("গোপন PIN/OTP/পাসওয়ার্ড চাওয়ার ইঙ্গিত আছে")
    val prize = listOf("লটারি", "পুরস্কার জিতেছেন", "আপনি জিতেছেন", "free gift", "won a prize", "claim prize")
    if (prize.any { s.contains(it) }) reasons.add("অপ্রত্যাশিত পুরস্কার/উপহারের দাবি আছে")
    val impersonation = listOf("ব্যাংক কর্মকর্তা", "কাস্টমার কেয়ার", "কাস্টমার কেয়ার", "সরকারি কর্মকর্তা", "support team", "bank officer")
    if (impersonation.any { s.contains(it) }) reasons.add("প্রতিষ্ঠানের পরিচয় ব্যবহার করা হয়েছে—স্বতন্ত্রভাবে যাচাই করুন")
    if (type == "অ্যাকাউন্ট" || type == "অনলাইন শপ") {
        if (listOf("শুধু অগ্রিম", "advance only", "অর্ধেক টাকা আগে", "no cash on delivery", "নাম্বার বন্ধ").any { s.contains(it) })
            reasons.add("লেনদেনের শর্তে অতিরিক্ত ঝুঁকির ইঙ্গিত আছে")
        if (listOf("অরিজিনাল", "original", "১০০% গ্যারান্টি", "100% guaranteed").any { s.contains(it) })
            reasons.add("বড় দাবি আছে—স্বাধীন রিভিউ/প্রমাণ যাচাই করুন")
    }
    val risk = when {
        reasons.count { it.contains("PIN/OTP") || it.contains("OTP") || it.contains("গোপন") } > 0 -> "উচ্চ ঝুঁকি"
        reasons.size >= 3 -> "উচ্চ ঝুঁকি"
        reasons.isNotEmpty() -> "সতর্কতা"
        else -> "কম সংকেত"
    }
    return risk to reasons.ifEmpty { listOf("পরিচিত ঝুঁকির স্পষ্ট সংকেত মেলেনি; তবুও প্রেরক ও তথ্য যাচাই করুন") }
}
private fun nowText() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())

@Composable
private fun UserApp(ctx: Context) {
    var tab by remember { mutableStateOf("পরীক্ষা") }
    var type by remember { mutableStateOf("মেসেজ") }
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<Pair<String, List<String>>?>(null) }
    var reports by remember { mutableStateOf(loadReports(ctx)) }
    var chatInput by remember { mutableStateOf("") }
    var chats by remember { mutableStateOf(prefs(ctx).getString(NOTES, "") ?: "") }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) runCatching {
            val arr = JSONArray()
            reports.forEach { r -> arr.put(JSONObject().put("id",r.id).put("type",r.type).put("content",r.content).put("risk",r.risk).put("reasons",JSONArray(r.reasons)).put("time",r.time)) }
            ctx.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(JSONObject().put("app","FraudGuard").put("reports",arr).toString(2)) }
        }
    }
    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("পরীক্ষা" to Icons.Default.Search, "স্থানীয় চ্যাট" to Icons.Default.Chat, "রিপোর্ট" to Icons.Default.Flag).forEach { (name, icon) ->
                    NavigationBarItem(selected = tab == name, onClick = { tab = name }, icon = { Icon(icon, null) }, label = { Text(name) })
                }
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(16.dp), color = Green, modifier = Modifier.size(48.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Shield, null, tint = Color.White) } }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("FraudGuard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
                    Text("অফলাইন প্রতারণা ঝুঁকি যাচাই", color = Color.Gray)
                }
            }
            when (tab) {
                "পরীক্ষা" -> {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("কী পরীক্ষা করবেন?", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("মেসেজ","লিংক","অ্যাকাউন্ট","অনলাইন শপ").forEach { item ->
                                    FilterChip(selected = type == item, onClick = { type = item }, label = { Text(item) })
                                }
                            }
                            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(), minLines = 5,
                                label = { Text("মেসেজ, URL, অ্যাকাউন্টের তথ্য বা দোকানের বিবরণ") },
                                placeholder = { Text("যেমন: OTP দিন, এখনই টাকা পাঠান…") })
                            Button(onClick = { if (input.isNotBlank()) result = analyze(input, type) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Security, null); Spacer(Modifier.width(8.dp)); Text("ঝুঁকি পরীক্ষা করুন")
                            }
                        }
                    }
                    result?.let { res ->
                        val danger = res.first == "উচ্চ ঝুঁকি"
                        Card(colors = CardDefaults.cardColors(containerColor = if (danger) Color(0xFFFFEEEE) else Color(0xFFEAF7F0))) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("ফলাফল: ${res.first}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = if (danger) Color(0xFFB42318) else Green)
                                res.second.forEach { Text("• $it") }
                                Text("এটি নিয়মভিত্তিক প্রাথমিক যাচাই; নিশ্চিত রায় নয়।", color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                                Button(onClick = {
                                    saveReport(ctx, Report(System.currentTimeMillis().toString(), type, input, res.first, res.second, nowText()))
                                    reports = loadReports(ctx); tab = "রিপোর্ট"
                                }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Flag, null); Spacer(Modifier.width(6.dp)); Text("রিপোর্টে সংরক্ষণ করুন") }
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF6DB))) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.Lightbulb, null, tint = Color(0xFF8A5A00))
                            Spacer(Modifier.width(8.dp))
                            Text("কখনো OTP, PIN বা পাসওয়ার্ড শেয়ার করবেন না। সন্দেহ হলে পরিচিত অফিসিয়াল নম্বরে যোগাযোগ করুন।")
                        }
                    }
                }
                "স্থানীয় চ্যাট" -> {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("এই ফোনের নোট/চ্যাট", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("এটি শুধু এই ডিভাইসে সংরক্ষিত। অন্য ব্যক্তির কাছে মেসেজ পাঠায় না।")
                            if (chats.isNotBlank()) Text(chats, modifier = Modifier.fillMaxWidth().padding(8.dp))
                            OutlinedTextField(value = chatInput, onValueChange = { chatInput = it }, modifier = Modifier.fillMaxWidth(), label = { Text("নোট বা মেসেজ লিখুন") })
                            Button(onClick = {
                                if (chatInput.isNotBlank()) {
                                    chats += (if (chats.isBlank()) "" else "\n\n") + "[$nowText] $chatInput"
                                    prefs(ctx).edit().putString(NOTES, chats).apply()
                                    chatInput = ""
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("ডিভাইসে সংরক্ষণ") }
                        }
                    }
                }
                else -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { exportLauncher.launch("fraudguard-reports.json") }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(5.dp)); Text("রিপোর্ট এক্সপোর্ট") }
                        OutlinedButton(onClick = { reports = loadReports(ctx) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(5.dp)); Text("রিফ্রেশ") }
                    }
                    if (reports.isEmpty()) Text("এখনো কোনো রিপোর্ট নেই।")
                    reports.forEach { r ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("${r.type} • ${r.risk}", fontWeight = FontWeight.Bold, color = if (r.risk == "উচ্চ ঝুঁকি") Color(0xFFB42318) else Green)
                                Text(r.content, maxLines = 4)
                                Text(r.time, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                Text(r.reasons.joinToString(" • "), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            Text("FraudGuard • অফলাইন লোকাল ডেটা", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
        }
    }
}
